Use with:

(No-Intro)
2433 - Little Busters - Converted Edition (Japan) (Disc 1).iso
MD5 - 558ea2c5f1a337d51def14e85502c1a6
CRC - 61AAFFE1

(No-Intro)
2433 - Little Busters - Converted Edition (Japan) (Disc 2).iso
MD5 - 36bf276dee1fbe8a100c68b008814e05
CRC - 36539437