Use with:

Banjo-Kazooie (USA).z64 (No-Intro)
b29599651a13f681c9923d69354bf4a3
AD429961
