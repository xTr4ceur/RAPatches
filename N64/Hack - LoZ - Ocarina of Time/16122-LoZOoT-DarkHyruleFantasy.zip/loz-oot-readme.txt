Use with:

(No Intro)
File:               Legend of Zelda, The - Ocarina of Time (USA).z64
BitSize:            256 Mbit
Size (Bytes):       33554432
CRC32:              CD16C529
MD5:                5BD1FE107BF8106B2AB6650ABECD54D6