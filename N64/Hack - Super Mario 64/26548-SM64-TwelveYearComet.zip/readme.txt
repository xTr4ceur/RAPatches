Use With:

Super Mario 64 (USA).z64 [No-Intro]
MD5: 20b854b239203baf6c961b850a4a51a2
CRC32: 3ce60709