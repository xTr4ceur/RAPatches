Use with:

Super Mario 64 (USA).z64 (No Intro)
20b854b239203baf6c961b850a4a51a2
