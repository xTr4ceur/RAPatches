Use with:

Tsumi to Batsu - Hoshi no Keishousha (Japan).z64 (No Intro)
a0657bc99e169153fd46aeccfde748f3