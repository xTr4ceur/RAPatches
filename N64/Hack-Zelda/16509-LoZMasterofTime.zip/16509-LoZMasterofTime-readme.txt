Use with:

Legend of Zelda, The - Ocarina of Time (USA).z64 (No-Intro)
5bd1fe107bf8106b2ab6650abecd54d6
CD16C529
