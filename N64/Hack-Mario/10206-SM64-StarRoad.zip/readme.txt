Use with:

Super Mario (USA).z64 (No Intro - BigEndian)
20b854b239203baf6c961b850a4a51a2