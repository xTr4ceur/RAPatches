Use with:

Mario Party 2 (USA).z64 (No-Intro)
04840612a35ece222afdb2dfbf926409
E58A1955
