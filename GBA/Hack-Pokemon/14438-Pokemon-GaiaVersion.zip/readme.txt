Use with:

No Intro
Pokemon - FireRed Version (USA).gba
e26ee0d44e809351c8ce2d73c7400cdd
DD88761C