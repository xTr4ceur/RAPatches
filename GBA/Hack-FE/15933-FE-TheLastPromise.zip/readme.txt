Use with:

No Intro
Fire Emblem (USA, Australia).gba
f1a1b9742fcd467a531dd4314c4e7d19
2A524221