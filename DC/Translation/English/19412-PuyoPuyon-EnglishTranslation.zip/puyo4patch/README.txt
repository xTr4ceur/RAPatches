Puyo Puyo~n English Translation Patch by Precise Museum
v1.0
----

This patch supports the GDI version of the game and a CDI version of the game.
Emulator users should use a GDI.

How to Patch a GDI Version of the Game
--------------------------------------
On Windows:
	Use Universal Dreamcast Patcher, your GDI, and the .dcp file included with this patch.
	The rest should be self-explanatory.
	Download Universal Dreamcast Patcher here:
		https://github.com/DerekPascarella/UniversalDreamcastPatcher/releases/
	Get the regular zip, not the source code.
On GNU/Linux:
	Look inside of the included posix.tar.xz file for software and instructions.
On Mac:
	The GNU/Linux patching program should work on macOS, but it's untested and will be a hassle to set up if you're not used to downloading and running source code.
	You're on your own if you want to try.
	Alternatively, you can patch a CDI version of the game and use it on an emulator.
	See the next section.

How to Patch a CDI Version of the Game
--------------------------------------
To make things easier, we do not generate a brand new CDI. An existing CDI is patched, instead.

1. Get a version of the game in CDI format.
	There are a few variants and you need a specific one.
	If you have the wrong file, the tool will refuse to patch it, so there's no harm in trying.
	Here are a few checksums if you want to verify ahead of time anyway:
		crc32: b1ea841b
		md5sum: dd936022d42604f6746ca5df2848c992
		sha256sum: 6ab5f6e8323cb5ab80fe423e8e855d87d7afbea344f94a2e27716fed74a37b4d
2. Download a program that can apply Xdelta patches.
	For Windows:
		https://www.romhacking.net/utilities/704/
		That program will work.
		If you want to use a different one, know that /very/ old versions of Xdelta won't work.
	For GNU/Linux:
		https://github.com/jmacd/xdelta
		Compile it yourself.
	For Mac:
		https://projects.sappharad.com/multipatch/
		You may need to rename `cdipatch.xdelta' to `cdipatch.delta' in order to select the file.
3. Apply the `cdipatch.delta' patch file to the CDI file using the program.

Both the original CDI and the modified one are 781 MiB.
That is small enough for an 80minute/"700Mib" CD-R.

Look elsewhere for a tutorial on how to burn and play CDI files on real hardware.

NOTE: There is a rare bug when playing the CDI on real hardware that may cause the BGM to play other tracks before looping.

Patch Changelog
---------------
v1.0 - (You are here)
	Initial release
