Use with:

(No Intro)
Bleach - Dark Souls (USA).nds
46df22ed5c0e9e9bf8162a1c3508f4f2
AFD3B264