Use with:

(No Intro)
World Ends with You, The (USA).nds
3bfc95753b37c97a6d30018630048a51
9BD848A7