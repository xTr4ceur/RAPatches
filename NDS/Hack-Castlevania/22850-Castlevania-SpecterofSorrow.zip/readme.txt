Use with:

(No Intro)
File:               Castlevania - Dawn of Sorrow (USA).nds
BitSize:            512 Mbit
Size (Bytes):       67108864
CRC32:              135737F6
MD5:                CC0F25B8783FB83CB4588D1C111BDC18