Use any of these patches with:

(No-Intro)
File:               Pokemon - Platinum Version (USA).nds
Size (Bytes):       134217728
CRC32:              9253921D
MD5:                D66AD7A2A0068B5D46E0781CA4953AE9