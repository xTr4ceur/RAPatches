Use with:

(No Intro)
File:               BS Zelda no Densetsu - Dai-1-wa (Japan) (Rerun) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              79D50FB1
MD5:                2ECEADD8A2CAB8C01EF52DD61616485C

File:               BS Zelda no Densetsu - Dai-2-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              D6E59847
MD5:                9519E4EBF147AB68C514E2A23F1B13C9

File:               BS Zelda no Densetsu - Dai-3-wa (Japan) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              F01EEB07
MD5:                719A82679B24FD100FF1F8D4545DEAED

File:               BS Zelda no Densetsu - Dai-4-wa (Japan) (Rerun) (SoundLink).bs
BitSize:            8 Mbit
Size (Bytes):       1048576
CRC32:              916D3811
MD5:                57F263A844DCAB95A83BCAA7A7FD0CB0