Use with:

(Redump)
Metal Gear Solid (USA) (Disc 1).bin
f1ff786c5ff2fc4c0701a1fee068ea95
51F233CD

Metal Gear Solid (USA) (Disc 2).bin
716e6b7d5e89b03a7eb028acb9068d91
E32F4A7E