Use with:

(Redump)
Breath of Fire IV (USA) (Track 1).bin
MD5: 1e7458c1049ea890d06875ecd482f803
CRC: 9274FE89