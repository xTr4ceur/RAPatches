﻿********************************************************************************
*                                Community Pom                                 *
*                          English Translation Patch                           *
*                           by LIPEMCO! Translations                           *
*                              v1.0 (4 Oct 2021)                               *
*                                                                              *
*                               Supper -- Hacking                              *
*                        TheMajinZenki -- Translation                          *
*                               cccmar -- Editing and Testing                  *
*                             Xanathis -- Guidebook Scans, Testing             *
*                                         and PR Coach                         *
********************************************************************************

Something's been snacking on Woolly Village's adorable Meymeys, and the 
townspeople aren't happy about it! While the villagers blame it on the 
mysterious rabbitlike Poms that appeared when the moon vanished five years ago, 
young Lulu knows better. With the magic staff gifted to her by the Poms in hand, 
she sets off on a quest to find the Poms, build a community where they can live 
in peace, and discover the truth behind all the incidents. And raid every 
dresser in the continent for trading cards along the way.

Community Pom is a 1997 action RPG/simulation game for the PlayStation, 
developed and published by Fill in Cafe (best known for the Asuka 120% and Kendo 
Rage/Makeruna! Makendou series). With gameplay reminiscent of classic 2D Zelda 
titles and perhaps most particularly influenced by Magic Knight Rayearth on the 
Sega Saturn, the game puts its own spin on things by throwing a simple but fun 
pet raising simulation into the mix, with the player rearing Poms to increase 
their combat stats and unlock new features and abilities. Imagine Zelda with a 
Chao Garden, and that the Chao Garden was actually useful.

This patch fully translates the game into English. In addition to translating 
the game, we've also scanned and partially translated the game's official 
guidebook; it should come bundled with the patch download, and we strongly 
recommend learning the basic controls from it before playing.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Bugs and Fixes
  IV.   Authors' Comments
  V.    Special Thanks
  VI.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Two methods of patching are provided. Choose one of the following based on the 
format of your disc image:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image

These options are explained in the subsections that follow.

  -------------------
  - BEFORE STARTING -
  -------------------

There are two known versions of this game: the original, which was 
self-published in 1997 by Fill in Cafe, and the updated rerelease, published in 
1999 by Family Soft (who added the subtitle "Omoide o Dakishimete" to the box 
art, though not in the game itself). The versions are easily distinguished by 
checking the title screen; the original's copyright message is "©1997 Fill in 
Cafe Co., Ltd.," while the rerelease's is "©1999 Family soft Co., Ltd."

This translation is based on the original 1997 version, but patches are provided 
for both versions – the 1999 version will simply be converted to the 1997 
version in the patching process. Before starting, determine which version of the 
game you have and use it to select the appropriate patching process below.

It's worth noting that the 1997 version of the game has a single sector at the 
end of the data track that appears to have been somehow misformatted on the 
original disc. Some online distributions of the game seem to zero out this 
sector instead of preserving the "bad" data; unfortuantely, this makes those 
disc images incompatible with the patch, which expects a raw, "uncorrected" disc 
rip. The 1999 version doesn't have any such issues, so try using that instead if 
you're having problems patching the 1997 version.

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE or IMG+CUE format; more exotic 
formats are not supported. It's unfortunately not uncommon to come across disc 
images that don't use the standard extensions used in this section, or use them 
differently from normal, which makes things very confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distribution 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent the Redump disc image, just split up into its 
component tracks.
  
  - A CUE file is not actually needed for the patching process, so don't worry 
if you only have a CCD and no CUE.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------

You can patch using this method if your disc image *exactly* matches one of the 
verified "good" images as listed on Redump.org, and if all the tracks on the 
disc are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

  1997 VERSION (copyright Fill in Cafe): http://redump.org/disc/37560/
    Redump name: Community Pom
    CRC32:       2e95fd97
    MD5:         27ff34f19917b0457fbc3b8eb187c89b
    SHA-1:       ab87251a599dfc1e0ca00eabc20aced7bd404f50

  1999 VERSION (copyright Family Soft): http://redump.org/disc/60074/
    Redump name: Community Pom: Omoide o Dakishimete
    CRC32:       b074be12
    MD5:         e1d3f69d6eccd1855db744ad78ee025e
    SHA-1:       f5c249122088312c142bfb97cbbc5ec3852bc75e

If your disc image is a match, then all you need to do is apply an xdelta patch 
to the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch files in the "redump_patch" folder. Pick the 
.xdelta file whose version label matches your disc: "[v1.0-1997]" for the 
original release, or "[v1.0-1999]" for the rerelease.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the 
appropriate patch to the BIN or IMG file. If you get an error, you'll need to 
try the other patching method below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Community Pom EN [v1.0] Redump.cue". Rename your patched disc image so it has 
*exactly* the same name as the CUE, except with a .bin extension instead of 
.cue. Note that at this point, it doesn't matter which version you patched – the 
output disc image will always be the same, regardless of which version you 
started with.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or play it on real hardware, if you have the means 
to do that; if it turns out not to work, we look forward to your complaints.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc images, but splits them up into separate tracks instead of 
combining them into a single file. This are easily recognized by the presence of 
5 separate BIN files and a single CUE.
  
  Before patching: 
  
  - Make sure that your disc's CUE file has a name like "Community Pom 
(Japan).cue" (1997 version) or "Community Pom - Omoide o Dakishimete 
(Japan).cue" (1999 version).
  
  - Make sure that the BIN files are named in the format "Community Pom (Japan) 
(Track 1).bin", "Community Pom (Japan) (Track 2).bin", etc., up through 
"Community Pom (Japan) (Track 5).bin". If patching the rerelease, the base name 
should again be "Community Pom - Omoide o Dakishimete".
    IMPORTANT: It's critical that the CUE has *exactly* the same name as the BIN 
files except without a track number; the patcher script assumes that it can add 
a track number to the CUE file's name in order to locate the BIN files. If 
necessary, rename your CUE file to match the BIN files. In particular, some 
distributions label the CUE file with "(JP)" but the BIN files with "(Japan)"; 
this isn't the same, so don't be fooled! Rename the CUE to use "(Japan)" 
instead.
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch_1997.bat" (if patching 1997 
version) or "binpatch_1999.bat" (if patching 1999 version).
  
  3. If all goes well, this should produce a new, single-track disc image in the 
same directory. (This works by simply combining all the tracks together and then 
applying the same patch as in method A.)
     
  4. Use the CUE file in the "splitbin_patch" directory to play the game.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

Please note that if you run this game through an emulator, you may or may not 
need a Japanese BIOS image. Some emulators such as Mednafen require it, while 
others such as PCSXR have an option to simulate the BIOS if not available. For 
the sake of accuracy, we strongly recommend running the game with the BIOS if 
possible. The required BIOS image is for the SCPH-5500/v3.0J version (SHA-256 
hash 9c0421858e217805f4abe18698afea8d5aa36ff0727eb8484944e00eb5e7eadb); once you 
have such an image, check your emulator's documentation for instructions on how 
to configure it for use.

                    ****************************************
                    *         III. Bugs and Fixes          *
                    ****************************************

There are no known bugs caused by the translation itself. On the other hand, in 
the course of developing this patch, we uncovered a large number of bugs in the 
original game, which range from harmless to irritating to game-breaking. We 
fixed anything actively problematic, but left some minor issues as they were. 
This section lists what was changed and what wasn't.



These issues are fixed:

  - The game was intended to have a total of 42 unique trading cards. However, 
in the original 1997 release, trading card N.41 is unobtainable – the event to 
get it is in the game data, but not assigned to any clickpoint. This would have 
made it impossible to get the 42 cards needed to buy all the items at the 
Trader, but due to another bug, collecting card N.22 awards two cards instead of 
just one, meaning the 41 cards that are actually obtainable end up counting as 
42 (which is probably why this issue wasn't caught before release). The 1999 
revision makes card N.41 obtainable in its intended location, but still 
duplicates card N.22, making it possible to get credit for 43 cards in that 
version. This patch fixes both issues, leaving 42 unique cards as originally 
intended.

  - During a Dismonster attack in the Community, using summoning items (e.g. Red 
Hourglass or Bottled Fire) is dangerous in the 1997 version. If a summon 
animation is playing when the attack ends, either because its effects defeated 
all the enemies or the attack timed out on its own, Lulu's controls aren't 
unlocked afterward and remain disabled permanently, softlocking the game. This 
is fixed in the 1999 version and the translation.

  - In the original game, Community structures can end up in an invalid state 
that prevents most or all Poms from interacting with them. The cause isn't 
known, but this seems to occur fairly regularly when trying to construct/upgrade 
a large number of buildings at once. A house affected by this glitch can only be 
worked on by one specific Pom in the Community, and other Poms will simply 
ignore it until that Pom has done something to it or it's destroyed in a 
Dismonster attack. More critically, this can happen to the Field, with far worse 
consequences – it will permanently prevent crops from being farmed ever again on 
that save file. Though the exact source of the issue remains a mystery, the 
effects have been addressed, and these problems should no longer occur in the 
patch.

  - Pressing X (the text fast-forward button) while dialogue is printing is 
supposed to instantly print the rest of the current box of text. Due to a bug, 
there was a 50/50 chance that doing this would skip the current box entirely and 
immediately start printing the next one. Since this was extremely annoying, it's 
been fixed.

  - Similarly to the previous bug, when choosing an option at a multiple-choice 
prompt, holding X to fast-forward while pressing Circle to confirm the choice 
would result in the immediately following box of text being skipped over. Also 
annoying, also fixed.

  - Due to misformatted minimap data, opening the map during or immediately 
after the boss rematches on floor 1F of Castle Vajra would result in major 
graphical corruption if "Secret Map !" (the dungeon map) was collected prior to 
the fight. Aside from the map itself not displaying correctly, this caused 
lingering display glitches until a new room was entered. Should no longer occur.

  - Messages regarding the cost of treatment at a church were broken in a very 
chaotic and inconsistent fashion if the cost was over 100 and had a tens digit 
of zero (100-109, 200-209, etc.). Depending on the church, either one or both of 
the instances where the price is shown would be missing the zero in the tens 
place (e.g. "I donated $21" instead of "$201"), though the full amount would 
still be subtracted from Lulu's funds. These all display correctly in the patch.

  - The Community's name would previously not appear on the world map if opened 
during a Dismonster attack.



These minor issues from the original game have been left as-is:

  - Speedrunners, take note: each time you open and close the menu during a 
jump, the length of the jump is slightly extended. This can be chained 
repeatedly to cross much larger gaps than intended, allowing for minor shortcuts 
and sequence breaks here and there.

  - Opening a menu or status window at a precise moment while moving to a new 
screen will result in the menu running with heavy slowdown. It will otherwise 
function properly, and everything will return to normal as soon as it's closed.

  - If at critical HP and the invisibility spell is currently in effect, holding 
down the magic button will start the Critical Magic charging animation. However, 
this spell actually has no Critical Magic version, so charging it fully will 
have no effect.

  - If Lulu is holding a Pom as the second phase of the Bone to be Mild boss 
fight starts, it will "run away", leaving her holding empty air which can be 
"thrown" as if it were a Pom (with no effect, naturally).
  
  - Pressing Start to skip the intro during the very end of the sequence, when 
the camera is scrolling down from the sun to the cliff Lulu stands on, will 
cause it to snap to an incorrect position that leaves some or all of the 
background blacked out.

                    ****************************************
                    *        IV. Authors' Comments         *
                    ****************************************

  -------------------
  -- TheMajinZenki --
  -------------------

  Community Pom caught my interest due to its visual cuteness (it reminds me a 
bit of Madou Monogatari, another series I've worked on in the past). It's not my 
ideal project as the text is not as straightforward (due to the presence of 
random NPCs you can talk to), but it was a lot of fun to work on due to the 
mostly whimsical dialogue and funny main character. As you can read from the 
translation of the guide, the developers were planning for a lot more for this 
series, it's a shame in the end they only released this one, as I'm sure you'll 
also feel when you finish it. At any rate, I hope you enjoy it as much as I did 
translating it :)

  ------------
  -- cccmar --
  ------------

  Community Pom is an action RPG game with sim elements (the titular 
community-building) released in 1997. This game is actually quite unique, as you 
can make it much easier by doing the additional stuff in the community, but it's 
entirely optional - you don't 'have to' do it. Still it's definitely worth it. 
As for the other bits and pieces - the game has quite a few puns, and also a lot 
of silly humour. It also has some very salient references to Madou Monogatari, 
Dragon Quest and some other popular series at the time, but also - an area 
inspired by Alice in Wonderland. It's definitely in the top 5 projects we've 
worked on for me, had a blast checking the script, as well as playing the game 
proper. Reader, be sure to check the parts of the guide book we provided, for 
some additional hints that the game doesn't fully explain! Have fun!
  
  ------------
  -- Supper --
  ------------

  For some reason, despite this being one of the most complicated projects I've 
ever done, it somehow feels like it never happened. I guess having a months-long 
break in production spent subtitling cutscenes for Galaxy Fraulein Yuna really 
threw me off.
  
  I picked this game out after seeing it randomly mentioned somewhere a while 
back. I thought the name was stupid, so I looked into it, and it turned out (a.) 
it was a good game, (b.) no one had ever heard of it, and (c.) it was about a 
magical girl and/or girl who does magic. With the trifecta complete, I was 
morally obliged to do everything in my power to make a translation happen, and 
here we are.
  
  This is the second PlayStation game I've done a translation hack for, and also 
the first ARPG. With Remote Control Dandy, I was able to lean on the existing 
scripting system to half-ass my way out of having to make a lot of low-level 
changes, but this time around I pretty much had to program everything myself. I 
think that for once, the increased complexity is readily visible. I mean, you 
had to scroll past that mile-long list of original-game bugs I fixed to get 
here, right?
  
  Overall, this is pretty unquestionably the most complicated text system I've 
ever written. I fully converted the game from a standard rendered font to a 
bitmapped one using a text caching system that's either genius or utter 
stupidity (probably the latter), expanded the text box from three to four lines, 
and implemented dynamic line wrapping to allow things like custom player names 
to be smoothly integrated into the dialogue. I don't even understand how half 
the stuff I wrote works anymore, but I'm happy as long as it does.
  
  The Japanese version of the game doesn't do colored text or underline effects; 
those were added for the translation. The main motivation for this was that the 
Japanese script is extraordinarily fond of using <angle brackets> around text to 
indicate "emphasis" or "importance." As a result of a certain previous 
translation project of ours that shall not be named, I think we've all come to 
agree that doing that in English is really, really annoying, so I cooked up the 
new effects as a replacement. Looks better to me, at least. (Fun fact: This 
style of bracketing is such a common thing in Japan that Japanese translations 
of Western games sometimes add brackets *into* the script where there were 
originally none!)
  
  A few people might recognize the font used in the translation, which I ended 
up recycling from Madou Monogatari I. I was planning to redraw it, but hadn't 
gotten around to it by the time we were starting to put the text in the game, 
and at that point I decided it wasn't worth the effort. I think it fits, though. 
Arle and Lulu would make a pretty good team, right?
  
  Anyway, we put a lot of work into this and I could carry on about it for a lot 
longer, but this is probably more than enough for anyone. I think this is one of 
the better games we've translated, and I hope at least a few people will enjoy 
it. It's by no means a difficult game, but it has that certain quality that 
makes it fun just to run around and bash every enemy even when you don't need 
to, and I think that's a sign of a game that had some deep passion put into it. 
I can see why Fill in Cafe felt confident they had a hit with this one. Too bad 
it, uh, didn't exactly work out for them...
  
                    ****************************************
                    *          V. Special Thanks           *
                    ****************************************

Thanks to けーしぃ (KC), whose playthrough of the game on Niconico was used as a 
reference during production: 
https://www.nicovideo.jp/user/46094845/mylist/49967513

Additional thanks goes to SadNES cITy Translations for the Delta Patcher 
program, which is bundled with this patch as a convenience.

                    ****************************************
                    *         VI. Version History          *
                    ****************************************

v1.0 (4 Oct 2021): Initial release.
