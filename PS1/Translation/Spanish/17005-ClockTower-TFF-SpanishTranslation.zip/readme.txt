Use with:

(Redump)
Clock Tower - The First Fear (Japan) (Track 1).bin
MD5: 6968ba39636641c4d8895335a13f7e98
CRC32: DAB05773